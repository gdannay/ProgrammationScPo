library(testthat)
library(PracticePackage)

test_check("PracticePackage")
